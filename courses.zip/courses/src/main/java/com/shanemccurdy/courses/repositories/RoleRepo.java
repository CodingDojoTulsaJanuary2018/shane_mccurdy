package com.shanemccurdy.courses.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.shanemccurdy.courses.models.Role;

public interface RoleRepo extends CrudRepository<Role, Long> {
	List<Role> findAll();
    List<Role> findByName(String name);
}
