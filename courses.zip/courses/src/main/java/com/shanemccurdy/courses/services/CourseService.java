package com.shanemccurdy.courses.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.shanemccurdy.courses.models.Course;
import com.shanemccurdy.courses.models.User;
import com.shanemccurdy.courses.repositories.CourseRepo;
import com.shanemccurdy.courses.repositories.UserRepo;


@Service
public class CourseService {
	private UserRepo userRepo;
	private CourseRepo courseRepo;
	public CourseService(UserRepo userRepo, CourseRepo courseRepo) {
		this.userRepo = userRepo;
		this.courseRepo = courseRepo;
	}
	
	public List<Course> findAll() {
		return courseRepo.findAll();
	}
	
	public void addUserToCourse(User user, Course course ) {
		course.pushUser(user);
		courseRepo.save(course);
	}
	public void removeUserFromCourse(User user, Course course) {
		course.popUser(user);
		courseRepo.save(course);
	}
	
	public Course getOneById(Long id) { //bypasses the optional<Course> restrictions - sends back empty/new user if no match 
		List<Course> list = courseRepo.findAll();
		for(int x = 0; x < list.size(); x++) {
			if (list.get(x).getId() == id) {
				return list.get(x);
			}
		}
		return new Course();
	}
	
	public void saveCourse(Course course) {
		System.out.println("calling : courseRepo.save(course)");
		System.out.println(course.getName() +  course.getInstructor() + course.getClasslimit() );
		courseRepo.save(course);
	}

}
