package com.shanemccurdy.courses.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.shanemccurdy.courses.models.Course;

public interface CourseRepo extends CrudRepository<Course, Long> {
	List<Course> findAll();
	Optional<Course> findById(Long id);
	void deleteById(Long id);
}
