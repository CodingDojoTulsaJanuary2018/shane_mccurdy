package com.shanemccurdy.courses.controllers;

import java.security.Principal;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.shanemccurdy.courses.models.Course;
import com.shanemccurdy.courses.models.User;
import com.shanemccurdy.courses.services.CourseService;
import com.shanemccurdy.courses.services.UserService;
import com.shanemccurdy.courses.validator.UserValidator;

@Controller
public class RouteController {
	
	private UserService userService;
	private UserValidator userValidator;
	private CourseService courseService;
    public RouteController(UserService userService, UserValidator userValidator, CourseService courseService) {
        this.userService = userService;
        this.userValidator = userValidator;
        this.courseService = courseService;
    }
    
    
    @RequestMapping("/courses") // ON SUCESSFUL LOGIN LANDING/HOME 
	public String coursesHome( Principal principal, Model model ) { //allCourses
    	String user = principal.getName();
    	model.addAttribute("user", userService.findByEmail(user));
    	System.out.println("calling : courseService.findAll()");
        model.addAttribute("allCourses", courseService.findAll());
		return "Dashboard.jsp";
	}
    @RequestMapping("/courses/new") // renders form for adding a new Course
	public String coursesNew( Principal principal, Model model, @ModelAttribute("newCourse") Course newCourse 
			) { 
    	String user = principal.getName();
    	model.addAttribute("user", userService.findByEmail(user));
		return "AddCourse.jsp";
	}
     
    @PostMapping("/courses/new") // POST - Create new event
   	public String postCoursesHome(@Valid @ModelAttribute("newCourse") Course newCourse,
			BindingResult newResult, Model model) {
    	if(newResult.hasErrors()) {
    		return "AddCourse.jsp";
    	} else {
    		System.out.println("calling : courseService.saveCourse(newCourse)");
    		courseService.saveCourse(newCourse);
    		return "redirect:/courses";
    	}
   	}
    
    @RequestMapping("/courses/{id}/enroll") // GET - enroll user in course
   	public String enroll(Principal principal, @PathVariable("id") Long id) {
    	User user = userService.findByEmail( principal.getName() );
    	Course course = courseService.getOneById(id);
    	courseService.addUserToCourse(user, course);
    	return "redirect:/courses";
   	}
    
    @RequestMapping("/courses/{id}") // show event by id
   	public String eventById(Principal principal, Model model, @PathVariable("id") Long id) {
    	model.addAttribute("user", userService.findByEmail(principal.getName() ) );
    	model.addAttribute("course", courseService.getOneById(id));
    	return "ShowCourse.jsp";
   	}
    
    
    @RequestMapping("/courses/{id}/unenroll") 
   	public String postEventById(Principal principal, @PathVariable("id") Long id) {
    	User user = userService.findByEmail( principal.getName() );
    	Course course = courseService.getOneById(id);
    	courseService.removeUserFromCourse(user, course);
   		return "redirect:/courses/"+id;
   	}
    
    
    
    @RequestMapping("/courses/{id}/edit") // will get event by id edit page - for author_user only
   	public String editEventById(Model model, @PathVariable("id") Long id ) {
    	model.addAttribute("course", courseService.getOneById(id));
   		return "EditCourse.jsp";
   	}
    @PostMapping("/courses/{id}/edit") // POST - update event by id - for author_user only
   	public String postEditEventById( @Valid @ModelAttribute("course") Course course,
			BindingResult newResult, Model model ) {
    	if(newResult.hasErrors()) {
    		return "EditCourse.jsp";
    	} else {
    		courseService.saveCourse(course);
    		return "redirect:/courses/"+ course.getId();
    	}
   	}
    
    
    @RequestMapping("/courses/{id}/delete") // GET - delete event by id - for author_user only
   	public String postDeleteEventById() {
   		return "redirect:/courses/";
   	}
    
    
    //=========== LOGIN - REGISTRATION - LOGOUT ===========//
	@RequestMapping("/login") // catches and redirects goofy results from Spring Security - for cleaner routing
	public String loginBounce(@RequestParam(value="error", required=false) String error,
			@RequestParam(value="logout", required=false) String logout,
			@RequestParam(value="success", required=false) String success) {
		if (error!=null) {
			return "redirect:/?error"; // changed "/login?error" to "/?error" 
		} if (logout!=null) {
			return "redirect:/?logout";
		} if (success!=null) {
			return "redirect:/?success";
		} else {
			return "redirect:/";
		}
	}
	
	@RequestMapping("/") // Landing page with forms...
    public String loginForm(Model model, HttpSession session,
    		@RequestParam(value="error", required=false) String error, 
			@RequestParam(value="logout", required=false) String logout,
			@RequestParam(value="success", required=false) String success,
    		@ModelAttribute("newUser") User newUser) {
		System.out.println("GET /");
		if(error != null) {
			model.addAttribute("errorMessage", "Invalid Credentials, Please try again.");
		    return "Login.jsp";
		}
		if(success != null) {
			model.addAttribute("registeredMessage", "Registration successful! You may now log in...");
		    return "Login.jsp";
		}
		if(logout != null) {
	      model.addAttribute("logoutMessage", "Logout Successful!");
	      System.out.println(">>>>>> /login?logout GET");
	      return "Login.jsp";
		}
        return "Login.jsp";
    } // END GET /
	
	@PostMapping("/") // POST / -Registration Validation
	public String loginPost( 
			@Valid @ModelAttribute("newUser") User newUser,
			BindingResult newResult, Model model
			) 
	{
		System.out.println(">>>>>> / POST");
		userValidator.validate(newUser, newResult);
		if(newResult.hasErrors()) { 		//invalid user info - passwords don't match
            return "Login.jsp";
        } else {
        	if(userService.findByEmail(newUser.getEmail()) == null) {
        		userService.saveWithUserRole(newUser);
        		//userService.saveUserWithAdminRole(newUser);
        		return "redirect:/login?success";
        	} else {
        		model.addAttribute("existingMessage", "That email address already has account associated with it. Maybe try logging in?");
                return "Login.jsp";
        	}
        }
	}// END POST / -Registration Validation
	
	
	
}
