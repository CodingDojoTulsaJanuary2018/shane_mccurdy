package com.shanemccurdy.courses.services;

import java.util.List;
import java.util.Optional;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.shanemccurdy.courses.models.User;
import com.shanemccurdy.courses.repositories.RoleRepo;
import com.shanemccurdy.courses.repositories.UserRepo;

@Service
public class UserService {
	private UserRepo userRepo;
	private RoleRepo roleRepo;
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	public UserService(UserRepo userRepo, RoleRepo roleRep,BCryptPasswordEncoder bCryptPasswordEncoder) {
		this.setUserRepo(userRepo);
		this.setRoleRep(roleRep);
		this.bCryptPasswordEncoder = bCryptPasswordEncoder;
	}
	
	//=== Methods ===//
	public User findByEmail(String email) {
		return userRepo.findByEmail(email);
	}
	public User getOneById(Long id) { //bypasses the optional<User> restrictions - sends back empty/new user if no match 
		List<User> list = userRepo.findAll();
		for(int x = 0; x < list.size(); x++) {
			if (list.get(x).getId() == id) {
				return list.get(x);
			}
		}
		return new User();
	}
	public Optional<User> findById(Long id) {
		return userRepo.findById(id);
	}
	public void deleteById(Long id) {
		userRepo.deleteById(id);
	}
	public List<User> findAll() {
		return  userRepo.findAll();
	}
	
	public void saveWithUserRole(User user) {
		System.out.println("NEW USER");
        user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
        user.setRoles(roleRepo.findByName("ROLE_USER"));
        userRepo.save(user);
    }
    public void saveUserWithAdminRole(User user) {
    	System.out.println("NEW ADMIN");
		user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
		user.setRoles(roleRepo.findByName("ROLE_ADMIN"));
        userRepo.save(user);
    }
    public void updateUserWithAdminRole(User user) {
    	System.out.println("UPDATED AS ADMIN");
		user.setRoles(roleRepo.findByName("ROLE_ADMIN"));
        userRepo.save(user);
    }

	//===Get and Set===//
	public UserRepo getUserRepo() {
		return userRepo;
	}
	public void setUserRepo(UserRepo userRepo) {
		this.userRepo = userRepo;
	}
	private void setRoleRep(RoleRepo roleRepo) {
		this.roleRepo = roleRepo;
	}

}
